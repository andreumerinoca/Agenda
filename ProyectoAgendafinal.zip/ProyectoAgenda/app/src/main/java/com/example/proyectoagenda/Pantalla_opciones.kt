package com.example.proyectoagenda

import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Pantalla_opciones : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pantalla_opciones)

        // Botón para salir de la APP
        val exitButton: Button = findViewById(R.id.exitButton)

        exitButton.setOnClickListener {
            //Sirve para cerrar UNA pantalla
            finish()
        }

        // Parte que genera modo oscuro
        val switchDarkModeButton = findViewById<Button>(R.id.modoOscuroClaroButton)

        // Cargar la preferencia guardada (modo oscuro o claro)
        val sharedPref = getSharedPreferences("ThemePrefs", MODE_PRIVATE)
        val isDarkMode = sharedPref.getBoolean("isDarkMode", false)

        // Ajustar el texto del botón según el tema actual
        updateButtonText(switchDarkModeButton, isDarkMode)

        // Cambiar el tema cuando el usuario haga clic en el botón
        switchDarkModeButton.setOnClickListener {
            val newMode = if (isDarkMode) {
                AppCompatDelegate.MODE_NIGHT_NO // Cambiar a modo claro
            } else {
                AppCompatDelegate.MODE_NIGHT_YES // Cambiar a modo oscuro
            }

            // Cambiar el modo de la app
            AppCompatDelegate.setDefaultNightMode(newMode)

            // Guardar la nueva preferencia
            saveThemePreference(!isDarkMode)

            // Actualizar el texto del botón
            updateButtonText(switchDarkModeButton, !isDarkMode)

            // Reiniciar la actividad para aplicar los cambios (opcional)
            recreate()
        }
    }

    // Función para guardar la preferencia del tema en SharedPreferences
    private fun saveThemePreference(isDarkMode: Boolean) {
        val sharedPref = getSharedPreferences("ThemePrefs", MODE_PRIVATE)
        val editor = sharedPref.edit()
        editor.putBoolean("isDarkMode", isDarkMode)
        editor.apply()  // Guarda los cambios
    }

    // Actualizar el texto del botón según el tema
    private fun updateButtonText(button: Button, isDarkMode: Boolean) {
        button.text = if (isDarkMode) "Cambiar a Modo Claro" else "Cambiar a Modo Oscuro"
    }
}

