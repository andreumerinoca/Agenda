package com.example.proyectoagenda

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        //Boton que lleva a la pantalla de Login
        val menu: Button = findViewById(R.id.gestionButton)
        menu.setOnClickListener {
            val intent = Intent(this, Pantalla_login::class.java)
            startActivity(intent)
        }

        //Boton que lleva a la pantalla de Registro
        val registro: Button = findViewById(R.id.registroButton)
        registro.setOnClickListener {
            val intent = Intent(this, Pantalla_registro::class.java)
            startActivity(intent)
        }

        //Boton que lleva a la pantalla de Opciones
        val opciones: Button = findViewById(R.id.opcionesButton)
        opciones.setOnClickListener {
            val intent = Intent(this, Pantalla_opciones::class.java)
            startActivity(intent)
       }

        //Boton que lleva a la pantalla de Eventos
        val eventos: Button = findViewById(R.id.eventosButton)
        eventos.setOnClickListener {
            val intent = Intent(this, Pantalla_organizarEventos::class.java)
            startActivity(intent)
        }

        //Boton para SALIR de la APP
        val exitButton: Button = findViewById(R.id.exitButton)
        exitButton.setOnClickListener {
            finishAffinity()
        }
    }
}

